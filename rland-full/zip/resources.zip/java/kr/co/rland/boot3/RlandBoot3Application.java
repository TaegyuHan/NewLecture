package kr.co.rland.boot3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RlandBoot3Application {

	public static void main(String[] args) {
		SpringApplication.run(RlandBoot3Application.class, args);
	}

}
