package kr.co.rland.boot3.service;

import kr.co.rland.boot3.entity.Notice;
import java.util.List;

public interface NoticeService {    
    List<Notice> getList();
}
