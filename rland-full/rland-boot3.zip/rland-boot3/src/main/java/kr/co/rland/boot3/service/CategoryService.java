package kr.co.rland.boot3.service;

import kr.co.rland.boot3.entity.Category;

import java.util.List;

public interface CategoryService {
    List<Category> getList();
}
