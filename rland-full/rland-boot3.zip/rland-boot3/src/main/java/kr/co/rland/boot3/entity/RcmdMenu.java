package kr.co.rland.boot3.entity;

public class RcmdMenu {
    private Long id;
    private Long menuId;
    private Long rMenuId;
    private Long memberId;
}
